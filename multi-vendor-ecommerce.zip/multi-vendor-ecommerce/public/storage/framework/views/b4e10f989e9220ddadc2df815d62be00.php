

<div
  :class="$store.sidebar.isMobileOpen ? 'block xl:hidden' : 'hidden'"
  class="fixed z-50 h-screen w-full bg-gray-900/50"
></div>
<?php /**PATH C:\xampp\htdocs\speedly_wind\multi-vendor-ecommerce\resources\views/layouts/admin/backdrop.blade.php ENDPATH**/ ?>