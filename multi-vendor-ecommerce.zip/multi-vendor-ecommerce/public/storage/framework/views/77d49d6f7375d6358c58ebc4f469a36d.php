<?php $__env->startSection('content'); ?>
  <div class="grid grid-cols-12 gap-4 md:gap-6">
    <div class="col-span-12 space-y-6 xl:col-span-7">
      <?php if (isset($component)) { $__componentOriginalcc6f8ad25af541e3fa4cb08458942845 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalcc6f8ad25af541e3fa4cb08458942845 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ecommerce.ecommerce-metrics','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ecommerce.ecommerce-metrics'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalcc6f8ad25af541e3fa4cb08458942845)): ?>
<?php $attributes = $__attributesOriginalcc6f8ad25af541e3fa4cb08458942845; ?>
<?php unset($__attributesOriginalcc6f8ad25af541e3fa4cb08458942845); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcc6f8ad25af541e3fa4cb08458942845)): ?>
<?php $component = $__componentOriginalcc6f8ad25af541e3fa4cb08458942845; ?>
<?php unset($__componentOriginalcc6f8ad25af541e3fa4cb08458942845); ?>
<?php endif; ?>
      <?php if (isset($component)) { $__componentOriginala2d14355b2163dbcf2c4983f67824d98 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala2d14355b2163dbcf2c4983f67824d98 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ecommerce.monthly-sale','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ecommerce.monthly-sale'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala2d14355b2163dbcf2c4983f67824d98)): ?>
<?php $attributes = $__attributesOriginala2d14355b2163dbcf2c4983f67824d98; ?>
<?php unset($__attributesOriginala2d14355b2163dbcf2c4983f67824d98); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala2d14355b2163dbcf2c4983f67824d98)): ?>
<?php $component = $__componentOriginala2d14355b2163dbcf2c4983f67824d98; ?>
<?php unset($__componentOriginala2d14355b2163dbcf2c4983f67824d98); ?>
<?php endif; ?>
    </div>
    <div class="col-span-12 xl:col-span-5">
        <?php if (isset($component)) { $__componentOriginal957636d633a7faaa6f525f02160454f5 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal957636d633a7faaa6f525f02160454f5 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ecommerce.monthly-target','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ecommerce.monthly-target'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal957636d633a7faaa6f525f02160454f5)): ?>
<?php $attributes = $__attributesOriginal957636d633a7faaa6f525f02160454f5; ?>
<?php unset($__attributesOriginal957636d633a7faaa6f525f02160454f5); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal957636d633a7faaa6f525f02160454f5)): ?>
<?php $component = $__componentOriginal957636d633a7faaa6f525f02160454f5; ?>
<?php unset($__componentOriginal957636d633a7faaa6f525f02160454f5); ?>
<?php endif; ?>
    </div>

    <div class="col-span-12">
      <?php if (isset($component)) { $__componentOriginalca5009a9c4c2c136e4109da267fcd9af = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalca5009a9c4c2c136e4109da267fcd9af = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ecommerce.statistics-chart','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ecommerce.statistics-chart'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalca5009a9c4c2c136e4109da267fcd9af)): ?>
<?php $attributes = $__attributesOriginalca5009a9c4c2c136e4109da267fcd9af; ?>
<?php unset($__attributesOriginalca5009a9c4c2c136e4109da267fcd9af); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalca5009a9c4c2c136e4109da267fcd9af)): ?>
<?php $component = $__componentOriginalca5009a9c4c2c136e4109da267fcd9af; ?>
<?php unset($__componentOriginalca5009a9c4c2c136e4109da267fcd9af); ?>
<?php endif; ?>
    </div>

    <div class="col-span-12 xl:col-span-5">
      <?php if (isset($component)) { $__componentOriginal3e9ac53279f1446e096b630991b3923d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3e9ac53279f1446e096b630991b3923d = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ecommerce.customer-demographic','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ecommerce.customer-demographic'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3e9ac53279f1446e096b630991b3923d)): ?>
<?php $attributes = $__attributesOriginal3e9ac53279f1446e096b630991b3923d; ?>
<?php unset($__attributesOriginal3e9ac53279f1446e096b630991b3923d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3e9ac53279f1446e096b630991b3923d)): ?>
<?php $component = $__componentOriginal3e9ac53279f1446e096b630991b3923d; ?>
<?php unset($__componentOriginal3e9ac53279f1446e096b630991b3923d); ?>
<?php endif; ?>
    </div>

    <div class="col-span-12 xl:col-span-7">
      <?php if (isset($component)) { $__componentOriginalcddb22c315ffd50021df116c9609f9ca = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalcddb22c315ffd50021df116c9609f9ca = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ecommerce.recent-orders','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ecommerce.recent-orders'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalcddb22c315ffd50021df116c9609f9ca)): ?>
<?php $attributes = $__attributesOriginalcddb22c315ffd50021df116c9609f9ca; ?>
<?php unset($__attributesOriginalcddb22c315ffd50021df116c9609f9ca); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcddb22c315ffd50021df116c9609f9ca)): ?>
<?php $component = $__componentOriginalcddb22c315ffd50021df116c9609f9ca; ?>
<?php unset($__componentOriginalcddb22c315ffd50021df116c9609f9ca); ?>
<?php endif; ?>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\speedly_wind\multi-vendor-ecommerce\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>