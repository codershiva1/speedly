<?php if (isset($component)) { $__componentOriginalfefb4fd9b7004fa65f70c415ac76903e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalfefb4fd9b7004fa65f70c415ac76903e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.site','data' => ['title' => $product->name]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layouts.site'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($product->name)]); ?>


<?php
$productDetails = [
    'Flavour' => 'Chocolate',
    'Storage Tips' => 'Keep refrigerated and away from direct sunlight. Consume within 2.5 months from the date of manufacturing',
    'Energy Per 100 g (kcal)' => '576',
    'Protein Per 100 g (g)' => '10',
    'Total Carbohydrates Per 100 g (g)' => '28',
    'Total Sugar Per 100 g (g)' => '21',
    'Added Sugars Per 100 g (g)' => '21',
    'Total Fat Per 100 g (g)' => '44.8',
    'Cholesterol Per 100 g (g)' => '0',
    'Dietary Fiber Per 100 g (g)' => '11.6',
    'Key Features' => [
        'Plant Based',
        'Gluten Free',
        'Dairy & Lactose Free',
        'Low Carb',
        'Refined Sugar Free',
        'PCOS Friendly',
        'Preservatives Free',
    ],
    'Ingredients' => 'Vegan 70% Dark Chocolate (Cacao, Unrefined Cane Sugar, Cacao Butter) (81%), Almonds (10%), Pumpkin Seeds, Goji Berries (6%), Rose Petals, Sea Salt',
    'Description' => $product->description,
    'Unit' => '50 g',
    'FSSAI License' => '12722055001288',
    'Allergen Information' => 'This product contains nuts. May contain traces of soy',
    'Shelf Life' => '4 months',
    'Country of Origin' => 'India',
];
?>


    <div class="bg-gray-50 min-h-screen ">
        <div class="max-w-7xl mx-auto px-4 sm:px-4 lg:px-4 py-4 space-y-8">

            <!-- PRODUCT TOP SECTION -->
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6 items-start bg-white p-2">

                <!-- LEFT COLUMN (IMAGE + DETAILS COLLAPSIBLE) -->
                <div class="space-y-6 md:pr-6 md:border-r md:border-gray-200">

                    <!-- IMAGE -->
                    <div class="relative">
                        <div class="aspect-square bg-gray-100 rounded-lg overflow-hidden flex items-center justify-center">
                            <?php $primaryImage = $product->images->first(); ?>
                            <?php if($primaryImage): ?>
                                <img src="https://speedlymart.com/storage/uploads/categories/3/image1.avif"
                                    alt="<?php echo e($product->name); ?>"
                                    class="w-full h-full object-cover">
                            <?php else: ?>
                                <span class="text-gray-400 text-sm">No Image</span>
                            <?php endif; ?>
                        </div>

                        <?php if($product->discount_price): ?>
                            <span class="absolute top-3 left-3 bg-green-600 text-white text-xs px-2 py-1 rounded-full">
                                SAVE ₹<?php echo e($product->price - $product->discount_price); ?>

                            </span>
                        <?php endif; ?>
                    </div>

                    <!-- PRODUCT DETAILS (COLLAPSIBLE) -->
                    <div class="bg-white rounded-lg">
                        <button
                            type="button"
                            onclick="toggleProductDetails()"
                            class="w-full flex justify-between items-center px-3 py-3 text-[14px] font-medium text-gray-900">
                            Product Details
                            <span id="productDetailsToggle" class="text-green-600 text-[12px] font-semibold">
                                View more
                            </span>
                        </button>

                        <div id="productDetailsContent"
                            class="hidden border-t px-3 pb-3 text-[12px] text-gray-700 space-y-3">

                            <?php $__currentLoopData = $productDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $label => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="grid grid-cols-2 gap-3">
                                    <p class="text-gray-500"><?php echo e($label); ?></p>

                                    <?php if(is_array($value)): ?>
                                        <ul class="list-disc pl-4 space-y-1 text-gray-900">
                                            <?php $__currentLoopData = $value; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li><?php echo e($item); ?></li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                    <?php else: ?>
                                        <p class="text-gray-900 leading-relaxed">
                                            <?php echo e($value); ?>

                                        </p>
                                    <?php endif; ?>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            <!-- DISCLAIMER -->
                            <p class="pt-2 text-[11px] text-gray-400 leading-relaxed">
                                Every effort is made to maintain accuracy of all information. However,
                                actual product packaging and materials may contain more and/or different information.
                            </p>
                        </div>
                    </div>

                </div>

                <!-- RIGHT COLUMN (PRODUCT INFO) - STICKY -->
                <aside class="sticky top-8 self-start space-y-4">

                    <!-- TITLE -->
                    <div>
                        <h1 class="text-xl md:text-2xl font-semibold text-gray-900">
                            <?php echo e($product->name); ?>

                        </h1>
                        <p class="text-xs text-gray-500 mt-1">
                            <?php echo e(optional($product->category)->name); ?>

                            <?php if($product->brand): ?> • <?php echo e($product->brand->name); ?> <?php endif; ?>
                        </p>
                    </div>

                    <!-- DELIVERY INFO -->
                    <div class="flex items-center gap-1 space-x-2 text-sm bg-green-50 text-green-700 px-3 py-2 rounded-lg w-fit">
                        🚚 Delivery in <span class="font-semibold">8 mins</span>
                    </div>

                    <!-- PRICE & ADD TO CART -->
                    <div class="flex flex-col space-y-3">
                        <div class="flex items-center space-x-3">
                            <span class="text-2xl font-bold text-gray-900">
                                ₹<?php echo e($product->discount_price ?? $product->price); ?>

                            </span>
                            <?php if($product->discount_price): ?>
                                <span class="text-sm text-gray-400 line-through">
                                    ₹<?php echo e($product->price); ?>

                                </span>
                            <?php endif; ?>
                        </div>

                        <?php if(auth()->guard()->check()): ?>
                            <form method="POST" action="<?php echo e(route('account.cart.store')); ?>" class="flex items-center gap-3">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="product_id" value="<?php echo e($product->id); ?>">
                                <?php if (isset($component)) { $__componentOriginald411d1792bd6cc877d687758b753742c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald411d1792bd6cc877d687758b753742c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.primary-button','data' => ['class' => 'w-full py-3 text-sm rounded-lg']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('primary-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'w-full py-3 text-sm rounded-lg']); ?>
                                    Add to Cart
                                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald411d1792bd6cc877d687758b753742c)): ?>
<?php $attributes = $__attributesOriginald411d1792bd6cc877d687758b753742c; ?>
<?php unset($__attributesOriginald411d1792bd6cc877d687758b753742c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald411d1792bd6cc877d687758b753742c)): ?>
<?php $component = $__componentOriginald411d1792bd6cc877d687758b753742c; ?>
<?php unset($__componentOriginald411d1792bd6cc877d687758b753742c); ?>
<?php endif; ?>
                            </form>
                        <?php else: ?>
                            <a href="<?php echo e(route('login')); ?>"
                            class="w-full text-center py-3 bg-indigo-600 text-white rounded-lg text-sm font-semibold">
                                Login to Add to Cart
                            </a>
                        <?php endif; ?>
                    </div>

                    <!-- RATINGS -->
                    <?php if($ratingCount): ?>
                        <div class="flex items-center text-sm text-gray-600">
                            <span class="mr-1 font-medium"><?php echo e(number_format($averageRating, 1)); ?></span>
                            <span class="text-yellow-400">★★★★★</span>
                            <span class="ml-1 text-xs text-gray-500">(<?php echo e($ratingCount); ?>)</span>
                        </div>
                    <?php endif; ?>

                    <!-- WHY SHOP FROM BLINKIT / SELLER INFO -->
                    <div class="border-t pt-4 space-y-3 text-xs text-gray-600">
                        <p class="font-semibold text-gray-900">Why shop from SpeedlyMart</p>
                        <div class="space-y-2">
                            <div class="flex items-start gap-2">
                                <span class="text-green-600">⚡</span>
                                <p>
                                    <span class="font-medium text-gray-900">Superfast delivery</span><br>
                                    Get your groceries delivered in minutes
                                </p>
                            </div>

                            <div class="flex items-start gap-2">
                                <span class="text-green-600">💰</span>
                                <p>
                                    <span class="font-medium text-gray-900">Best prices & offers</span><br>
                                    Great deals, discounts & savings everyday
                                </p>
                            </div>

                            <div class="flex items-start gap-2">
                                <span class="text-green-600">🛒</span>
                                <p>
                                    <span class="font-medium text-gray-900">Wide assortment</span><br>
                                    Choose from thousands of products
                                </p>
                            </div>
                        </div>

                        <?php if($product->vendor && $product->vendor->vendorProfile): ?>
                            <p class="text-gray-500 mt-2 text-xs">
                                Sold by
                                <a href="<?php echo e(route('vendors.show', $product->vendor->vendorProfile->slug)); ?>"
                                class="text-indigo-600 font-medium">
                                    <?php echo e($product->vendor->vendorProfile->store_name); ?>

                                </a>
                            </p>
                        <?php endif; ?>
                    </div>

                </aside>

            </div>

            <!-- REVIEWS SECTION -->
            <div class="grid grid-cols-1 md:grid-cols-3 gap-6">

                <!-- REVIEWS LIST -->
                <section class="md:col-span-2 bg-white rounded-xl shadow-sm p-5">
                    <h2 class="font-semibold text-gray-900 mb-4">
                        Customer Reviews
                    </h2>

                    <?php $__empty_1 = true; $__currentLoopData = $approvedReviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="border-b py-3 last:border-0">
                            <div class="flex justify-between text-xs">
                                <span class="font-semibold"><?php echo e($review->user->name); ?></span>
                                <span class="text-gray-400"><?php echo e($review->created_at->format('d M Y')); ?></span>
                            </div>
                            <div class="text-yellow-400 text-xs mt-1">
                                <?php echo e(str_repeat('★', $review->rating)); ?><?php echo e(str_repeat('☆', 5 - $review->rating)); ?>

                            </div>
                            <?php if($review->comment): ?>
                                <p class="text-sm text-gray-700 mt-1"><?php echo e($review->comment); ?></p>
                            <?php endif; ?>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <p class="text-sm text-gray-500">No reviews yet.</p>
                    <?php endif; ?>
                </section>

                <!-- REVIEW FORM -->
                <section class="bg-white rounded-xl shadow-sm p-5">
                    <h2 class="font-semibold text-gray-900 mb-3">Write a Review</h2>

                    <?php if(auth()->guard()->check()): ?>
                        <form method="POST" action="<?php echo e(route('shop.reviews.store', $product)); ?>" class="space-y-3">
                            <?php echo csrf_field(); ?>

                            <select name="rating" class="w-full border rounded-lg px-3 py-2 text-sm">
                                <?php for($i = 5; $i >= 1; $i--): ?>
                                    <option value="<?php echo e($i); ?>"><?php echo e($i); ?> Stars</option>
                                <?php endfor; ?>
                            </select>

                            <textarea name="comment" rows="3"
                                      class="w-full border rounded-lg px-3 py-2 text-sm"
                                      placeholder="Share your experience"></textarea>

                            <?php if (isset($component)) { $__componentOriginald411d1792bd6cc877d687758b753742c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald411d1792bd6cc877d687758b753742c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.primary-button','data' => ['class' => 'w-full']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('primary-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'w-full']); ?>
                                Submit Review
                             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald411d1792bd6cc877d687758b753742c)): ?>
<?php $attributes = $__attributesOriginald411d1792bd6cc877d687758b753742c; ?>
<?php unset($__attributesOriginald411d1792bd6cc877d687758b753742c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald411d1792bd6cc877d687758b753742c)): ?>
<?php $component = $__componentOriginald411d1792bd6cc877d687758b753742c; ?>
<?php unset($__componentOriginald411d1792bd6cc877d687758b753742c); ?>
<?php endif; ?>
                        </form>
                    <?php else: ?>
                        <p class="text-sm text-gray-500">
                            Please <a href="<?php echo e(route('login')); ?>" class="text-indigo-600">login</a> to review.
                        </p>
                    <?php endif; ?>
                </section>

            </div>

                <!-- SIMILAR PRODUCTS -->
            <?php if($similarProducts->isNotEmpty()): ?>
            <section class="mt-10">
                <h2 class="text-lg font-semibold mb-4">Similar Products</h2>
                <div class="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
                    <?php $__currentLoopData = $similarProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="bg-white rounded-xl border border-gray-200 hover:shadow-md transition-all p-2 flex flex-col">
                            
                            
                            <a href="<?php echo e(route('shop.show', $product->slug)); ?>" class="block">
                                <div class="w-full h-36 bg-gray-100 rounded-lg overflow-hidden flex items-center justify-center">
                                    <?php $img = $product->images->first(); ?>
                                    <?php if($img): ?>
                                        <img src="https://cdn.grofers.com/cdn-cgi/image/f=auto,fit=scale-down,q=70,metadata=none,w=270/da/cms-assets/cms/product/77a1f36d-1024-4d57-bbb1-190c016c134f.png" 
                                            class="w-full h-full object-contain" 
                                            alt="<?php echo e($product->name); ?>">
                                    <?php else: ?>
                                        <span class="text-gray-400 text-xs">No Image</span>
                                    <?php endif; ?>
                                </div>
                            </a>

                            
                            <span class="w-fit inline-flex items-center gap-1 bg-orange-50 text-yellow-900 text-xs font-semibold px-2.5 py-0.5 rounded-full mt-3">
                                <svg class="w-3.5 h-3.5 text-yellow-700" fill="currentColor" viewBox="0 0 20 20">
                                    <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm.75-12.75a.75.75 0 00-1.5 0v4.19l-2.2 2.2a.75.75 0 101.06 1.06l2.39-2.39V5.25z" clip-rule="evenodd" />
                                </svg>
                                8 MINS
                            </span>

                            <div class="mt-2 flex-1">
                                <p class="text-sm font-semibold text-gray-900 leading-tight line-clamp-2">
                                    <?php echo e($product->name); ?>

                                </p>

                                <?php if($product->size): ?>
                                    <p class="text-sm text-gray-500 mt-1"><?php echo e($product->size); ?></p>
                                <?php endif; ?>
                            </div>

                            
                            <div class="mt-3 flex items-center justify-between">
                                
                                
                                <div class="flex flex-col leading-tight">
                                    <span class="text-base font-bold text-gray-900">
                                        ₹<?php echo e($product->price); ?>

                                    </span>

                                    <?php if($product->discount_price): ?>
                                        <span class="line-through text-xs text-gray-400">
                                            ₹<?php echo e($product->discount_price); ?>

                                        </span>
                                    <?php endif; ?>
                                </div>

                                
                                <button class="px-4 py-1.5 border border-green-600 text-green-600 rounded-lg text-sm font-semibold hover:bg-green-50">
                                    ADD
                                </button>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </section>
            <?php endif; ?>

            <!-- TOP 10 PRODUCTS IN THIS CATEGORY -->
            <?php if($topCategoryProducts->isNotEmpty()): ?>
            <section class="mt-10">
                <h2 class="text-lg font-semibold mb-4">Top 10 Products in this Category</h2>
                <div class="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
                    <?php $__currentLoopData = $topCategoryProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="bg-white rounded-xl border border-gray-200 hover:shadow-md transition-all p-2 flex flex-col">
                            
                            
                            <a href="<?php echo e(route('shop.show', $product->slug)); ?>" class="block">
                                <div class="w-full h-36 bg-gray-100 rounded-lg overflow-hidden flex items-center justify-center">
                                    <?php $img = $product->images->first(); ?>
                                    <?php if($img): ?>
                                        <img src="https://cdn.grofers.com/cdn-cgi/image/f=auto,fit=scale-down,q=70,metadata=none,w=270/da/cms-assets/cms/product/c299d4a9-8e07-4660-a510-f973dcd2cadf.png" 
                                            class="w-full h-full object-contain" 
                                            alt="<?php echo e($product->name); ?>">
                                    <?php else: ?>
                                        <span class="text-gray-400 text-xs">No Image</span>
                                    <?php endif; ?>
                                </div>
                            </a>

                            
                            <span class="w-fit inline-flex items-center gap-1 bg-orange-50 text-yellow-900 text-xs font-semibold px-2.5 py-0.5 rounded-full mt-3">
                                <svg class="w-3.5 h-3.5 text-yellow-700" fill="currentColor" viewBox="0 0 20 20">
                                    <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm.75-12.75a.75.75 0 00-1.5 0v4.19l-2.2 2.2a.75.75 0 101.06 1.06l2.39-2.39V5.25z" clip-rule="evenodd" />
                                </svg>
                                8 MINS
                            </span>

                            <div class="mt-2 flex-1">
                                <p class="text-sm font-semibold text-gray-900 leading-tight line-clamp-2">
                                    <?php echo e($product->name); ?>

                                </p>

                                <?php if($product->size): ?>
                                    <p class="text-sm text-gray-500 mt-1"><?php echo e($product->size); ?></p>
                                <?php endif; ?>
                            </div>

                            
                            <div class="mt-3 flex items-center justify-between">
                                
                                
                                <div class="flex flex-col leading-tight">
                                    <span class="text-base font-bold text-gray-900">
                                        ₹<?php echo e($product->price); ?>

                                    </span>

                                    <?php if($product->discount_price): ?>
                                        <span class="line-through text-xs text-gray-400">
                                            ₹<?php echo e($product->discount_price); ?>

                                        </span>
                                    <?php endif; ?>
                                </div>

                                
                                <button class="px-4 py-1.5 border border-green-600 text-green-600 rounded-lg text-sm font-semibold hover:bg-green-50">
                                    ADD
                                </button>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </section>
            <?php endif; ?>



            <!-- PEOPLE ALSO BOUGHT -->
            <?php if($peopleAlsoBought->isNotEmpty()): ?>
            <section class="mt-10">
                <h2 class="text-lg font-semibold mb-4">People Also Bought</h2>
                <div class="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
                    <?php $__currentLoopData = $peopleAlsoBought; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="bg-white rounded-xl border border-gray-200 hover:shadow-md transition-all p-2 flex flex-col">
                            
                            
                            <a href="<?php echo e(route('shop.show', $product->slug)); ?>" class="block">
                                <div class="w-full h-36 bg-gray-100 rounded-lg overflow-hidden flex items-center justify-center">
                                    <?php $img = $product->images->first(); ?>
                                    <?php if($img): ?>
                                        <img src="https://cdn.grofers.com/cdn-cgi/image/f=auto,fit=scale-down,q=70,metadata=none,w=270/da/cms-assets/cms/product/2d87e7e0-d84b-4049-bb76-7962e83d9281.png" 
                                            class="w-full h-full object-contain" 
                                            alt="<?php echo e($product->name); ?>">
                                    <?php else: ?>
                                        <span class="text-gray-400 text-xs">No Image</span>
                                    <?php endif; ?>
                                </div>
                            </a>

                            
                            <span class="w-fit inline-flex items-center gap-1 bg-orange-50 text-yellow-900 text-xs font-semibold px-2.5 py-0.5 rounded-full mt-3">
                                <svg class="w-3.5 h-3.5 text-yellow-700" fill="currentColor" viewBox="0 0 20 20">
                                    <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm.75-12.75a.75.75 0 00-1.5 0v4.19l-2.2 2.2a.75.75 0 101.06 1.06l2.39-2.39V5.25z" clip-rule="evenodd" />
                                </svg>
                                8 MINS
                            </span>

                            <div class="mt-2 flex-1">
                                <p class="text-sm font-semibold text-gray-900 leading-tight line-clamp-2">
                                    <?php echo e($product->name); ?>

                                </p>

                                <?php if($product->size): ?>
                                    <p class="text-sm text-gray-500 mt-1"><?php echo e($product->size); ?></p>
                                <?php endif; ?>
                            </div>

                            
                            <div class="mt-3 flex items-center justify-between">
                                
                                
                                <div class="flex flex-col leading-tight">
                                    <span class="text-base font-bold text-gray-900">
                                        ₹<?php echo e($product->price); ?>

                                    </span>

                                    <?php if($product->discount_price): ?>
                                        <span class="line-through text-xs text-gray-400">
                                            ₹<?php echo e($product->discount_price); ?>

                                        </span>
                                    <?php endif; ?>
                                </div>

                                
                                <button class="px-4 py-1.5 border border-green-600 text-green-600 rounded-lg text-sm font-semibold hover:bg-green-50">
                                    ADD
                                </button>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </section>
            <?php endif; ?>

        </div>
    </div>



    <script>
function toggleProductDetails() {
    const content = document.getElementById('productDetailsContent');
    const toggle = document.getElementById('productDetailsToggle');

    const isOpen = !content.classList.contains('hidden');

    if (isOpen) {
        content.classList.add('hidden');
        toggle.innerText = 'View more';
    } else {
        content.classList.remove('hidden');
        toggle.innerText = 'View less';
    }
}
</script>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalfefb4fd9b7004fa65f70c415ac76903e)): ?>
<?php $attributes = $__attributesOriginalfefb4fd9b7004fa65f70c415ac76903e; ?>
<?php unset($__attributesOriginalfefb4fd9b7004fa65f70c415ac76903e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalfefb4fd9b7004fa65f70c415ac76903e)): ?>
<?php $component = $__componentOriginalfefb4fd9b7004fa65f70c415ac76903e; ?>
<?php unset($__componentOriginalfefb4fd9b7004fa65f70c415ac76903e); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\speedly_wind\multi-vendor-ecommerce\resources\views/shop/show.blade.php ENDPATH**/ ?>