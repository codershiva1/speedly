<?php if (isset($component)) { $__componentOriginalfefb4fd9b7004fa65f70c415ac76903e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalfefb4fd9b7004fa65f70c415ac76903e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.site','data' => ['title' => __('Customer Dashboard').' | '.config('app.name')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layouts.site'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(__('Customer Dashboard').' | '.config('app.name'))]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Customer Dashboard')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-6">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8 space-y-6">
            <div class="grid grid-cols-1 sm:grid-cols-4 gap-4">
                <div class="bg-white shadow-sm rounded-lg p-4">
                    <p class="text-xs text-gray-500"><?php echo e(__('Orders')); ?></p>
                    <p class="text-xl font-semibold mt-1"><?php echo e($ordersCount); ?></p>
                </div>
                <div class="bg-white shadow-sm rounded-lg p-4">
                    <p class="text-xs text-gray-500"><?php echo e(__('Pending')); ?></p>
                    <p class="text-xl font-semibold mt-1"><?php echo e($pendingOrdersCount); ?></p>
                </div>
                <div class="bg-white shadow-sm rounded-lg p-4">
                    <p class="text-xs text-gray-500"><?php echo e(__('Completed')); ?></p>
                    <p class="text-xl font-semibold mt-1"><?php echo e($completedOrdersCount); ?></p>
                </div>
                <div class="bg-white shadow-sm rounded-lg p-4">
                    <p class="text-xs text-gray-500"><?php echo e(__('Total Spent')); ?></p>
                    <p class="text-xl font-semibold mt-1">₹<?php echo e(number_format($totalSpent, 2)); ?></p>
                </div>
            </div>

            <div class="flex flex-wrap gap-3">
                <a href="<?php echo e(route('shop.index')); ?>" class="inline-flex items-center px-4 py-2 bg-indigo-600 border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest hover:bg-indigo-500">
                    <?php echo e(__('Shop Now')); ?>

                </a>
                <a href="<?php echo e(route('account.orders.index')); ?>" class="inline-flex items-center px-4 py-2 bg-white border border-gray-300 rounded-md font-semibold text-xs text-gray-700 uppercase tracking-widest hover:bg-gray-50">
                    <?php echo e(__('View Orders')); ?>

                </a>
                <a href="<?php echo e(route('account.cart.index')); ?>" class="inline-flex items-center px-4 py-2 bg-white border border-gray-300 rounded-md font-semibold text-xs text-gray-700 uppercase tracking-widest hover:bg-gray-50">
                    <?php echo e(__('View Cart')); ?>

                </a>
            </div>

            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900 text-sm">
                    <h3 class="font-semibold mb-3"><?php echo e(__('Recent Orders')); ?></h3>

                    <table class="min-w-full divide-y divide-gray-200">
                        <thead>
                            <tr>
                                <th class="px-3 py-2 text-left font-semibold text-xs"><?php echo e(__('Order #')); ?></th>
                                <th class="px-3 py-2 text-left font-semibold text-xs"><?php echo e(__('Date')); ?></th>
                                <th class="px-3 py-2 text-left font-semibold text-xs"><?php echo e(__('Status')); ?></th>
                                <th class="px-3 py-2 text-left font-semibold text-xs"><?php echo e(__('Total')); ?></th>
                                <th class="px-3 py-2"></th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-gray-100">
                            <?php $__empty_1 = true; $__currentLoopData = $recentOrders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td class="px-3 py-2"><?php echo e($order->order_number); ?></td>
                                    <td class="px-3 py-2"><?php echo e($order->created_at->format('d M Y H:i')); ?></td>
                                    <td class="px-3 py-2 text-xs"><?php echo e(ucfirst($order->status)); ?></td>
                                    <td class="px-3 py-2">₹<?php echo e(number_format($order->total_amount, 2)); ?></td>
                                    <td class="px-3 py-2 text-right">
                                        <a href="<?php echo e(route('account.orders.show', $order)); ?>" class="text-xs text-indigo-600 hover:underline"><?php echo e(__('View')); ?></a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="5" class="px-3 py-4 text-center text-gray-500"><?php echo e(__('No recent orders.')); ?></td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalfefb4fd9b7004fa65f70c415ac76903e)): ?>
<?php $attributes = $__attributesOriginalfefb4fd9b7004fa65f70c415ac76903e; ?>
<?php unset($__attributesOriginalfefb4fd9b7004fa65f70c415ac76903e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalfefb4fd9b7004fa65f70c415ac76903e)): ?>
<?php $component = $__componentOriginalfefb4fd9b7004fa65f70c415ac76903e; ?>
<?php unset($__componentOriginalfefb4fd9b7004fa65f70c415ac76903e); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\speedly_wind\multi-vendor-ecommerce\resources\views/customer/dashboard.blade.php ENDPATH**/ ?>