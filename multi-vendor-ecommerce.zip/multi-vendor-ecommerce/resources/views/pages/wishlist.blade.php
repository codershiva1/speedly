<x-layouts.site :title="__('Wishlist')">
    <div class="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-4 text-sm">
        <h1 class="text-2xl font-semibold text-gray-900 mb-2">Wishlist (Demo)</h1>
        <p class="text-gray-700">Wishlist functionality is not persisted in the database in this demo. Use this page as a placeholder to implement your own wishlist or favourites feature.</p>
    </div>
</x-layouts.site>
